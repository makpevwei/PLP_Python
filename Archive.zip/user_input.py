name = input("Enter your name: ")
age = input("Enter your age: ")
location = input("Enter your location: ")
print(f"Hello {name} you are {age} years old and live in {location}.")